import 'package:flutter/material.dart';
import '../neon_theme.dart';
import '../services/auth_service.dart';
import '../services/profile_service.dart';
import 'admin_screen.dart';
import 'friends_screen.dart';
import 'inbox_screen.dart';
import 'profile_screen.dart';
import 'video_chat_screen.dart';
import 'vip_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  final profileService=ProfileService(); int tab=0; String region='Worldwide',language='Any language',genderPreference='Everyone',displayName=''; bool loading=true,isVip=false,isAdmin=false; int coins=0; String? avatarUrl;
  @override void initState(){super.initState();_loadProfile();}
  Future<void> _loadProfile() async {
    final p = await profileService.loadMine();
    if (!mounted) return;

    if (p == null) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen(firstRun: true)),
      );
      if (mounted) await _loadProfile();
      return;
    }

    if (p['display_name'] == null) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen(firstRun: true)),
      );
      if (mounted) await _loadProfile();
      return;
    }

    setState(() {
      displayName = p['display_name']?.toString() ?? '';
      region = p['country']?.toString() ?? region;
      final savedLanguage = p['language']?.toString();
      if (savedLanguage != null && savedLanguage.isNotEmpty) {
        language = savedLanguage;
      }
      avatarUrl = p['avatar_url']?.toString();
      coins = (p['coins'] as num?)?.toInt() ?? 0;
      isVip = p['is_vip'] == true;
      isAdmin = p['is_admin'] == true;
      loading = false;
    });
  }
  @override Widget build(BuildContext context)=>Scaffold(extendBody:true,body:loading?const Center(child:CircularProgressIndicator()):IndexedStack(index:tab,children:[_discover(),const FriendsScreen(),const InboxScreen(),_profileHub()]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
    NavigationDestination(icon:Icon(Icons.travel_explore_rounded),label:'Discover'),NavigationDestination(icon:Icon(Icons.group_outlined),selectedIcon:Icon(Icons.group_rounded),label:'Friends'),NavigationDestination(icon:Icon(Icons.chat_bubble_outline_rounded),selectedIcon:Icon(Icons.chat_bubble_rounded),label:'Inbox'),NavigationDestination(icon:Icon(Icons.person_outline_rounded),selectedIcon:Icon(Icons.person_rounded),label:'Profile')
  ]));

  Widget _discover()=>Container(decoration:const BoxDecoration(gradient:RadialGradient(center:Alignment(-.8,-.65),radius:1.1,colors:[Color(0x3322D3EE),Color(0x00070816)])),child:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(20,18,20,110),children:[
    Row(children:[const NeonLogo(size:48),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('NEON WORLD',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900,letterSpacing:1.2)),Text('Meet the world live',style:TextStyle(color:Colors.white54))])),_coinPill()]),
    const SizedBox(height:30),Text('Hey $displayName 👋',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700)),const SizedBox(height:5),const Text('Who will you meet next?',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,height:1.05)),const SizedBox(height:22),
    NeonPanel(child:Column(children:[Row(children:[Expanded(child:_select('Region',region,['Worldwide','Israel','Europe','North America','South America','Asia','Africa','Oceania'],(v)=>setState(()=>region=v))),const SizedBox(width:10),Expanded(child:_select('Language',language,['Any language','English','Hebrew','Arabic','Spanish','French','German','Russian','Portuguese'],(v)=>setState(()=>language=v)))]),const SizedBox(height:10),_select('I want to meet',genderPreference,['Everyone','Man','Woman','Non-binary'],(v)=>setState(()=>genderPreference=v)),const SizedBox(height:18),SizedBox(width:double.infinity,height:62,child:DecoratedBox(decoration:BoxDecoration(gradient:const LinearGradient(colors:[NeonTheme.purple,NeonTheme.pink]),borderRadius:BorderRadius.circular(20),boxShadow:[BoxShadow(color:NeonTheme.purple.withValues(alpha:.35),blurRadius:24)]),child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:Colors.transparent,shadowColor:Colors.transparent),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>VideoChatScreen(region:region,language:language,genderPreference:genderPreference))),icon:const Icon(Icons.bolt_rounded,size:27),label:const Text('START VIDEO CHAT',style:TextStyle(letterSpacing:.5))))) ])),
    const SizedBox(height:16),Row(children:[Expanded(child:_mini(Icons.public_rounded,'Worldwide','Fast global matching')),const SizedBox(width:12),Expanded(child:_mini(Icons.shield_rounded,'Safer','Block • report • 18+'))]),const SizedBox(height:18),
    if(isVip)const NeonPanel(child:Row(children:[Icon(Icons.workspace_premium_rounded,color:Color(0xFFFFD76A)),SizedBox(width:10),Expanded(child:Text('VIP active • premium perks enabled',style:TextStyle(fontWeight:FontWeight.w800)))])),
    const SizedBox(height:18),Text('18+ only • Never share passwords, card details or private documents.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white.withValues(alpha:.42),fontSize:12))
  ])));
  Widget _coinPill()=>Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),decoration:BoxDecoration(color:const Color(0xFFFFD76A).withValues(alpha:.12),borderRadius:BorderRadius.circular(20)),child:Row(children:[const Icon(Icons.monetization_on_rounded,size:18,color:Color(0xFFFFD76A)),const SizedBox(width:5),Text('$coins',style:const TextStyle(fontWeight:FontWeight.w900))]));
  Widget _select(String l,String v,List<String>a,ValueChanged<String>f)=>DropdownButtonFormField<String>(value:v,isExpanded:true,decoration:InputDecoration(labelText:l,contentPadding:const EdgeInsets.symmetric(horizontal:13,vertical:12)),items:a.map((x)=>DropdownMenuItem(value:x,child:Text(x,overflow:TextOverflow.ellipsis))).toList(),onChanged:(x){if(x!=null)f(x);});
  Widget _mini(IconData i,String t,String s)=>NeonPanel(padding:const EdgeInsets.all(14),child:Row(children:[Icon(i,color:NeonTheme.blue),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(fontWeight:FontWeight.w800)),Text(s,style:TextStyle(color:Colors.white.withValues(alpha:.48),fontSize:11))]))]));

  Widget _profileHub()=>SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(20,25,20,110),children:[
    const Text('Profile',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:18),NeonPanel(child:Row(children:[CircleAvatar(radius:31,backgroundColor:NeonTheme.purple,backgroundImage:(avatarUrl??'').isNotEmpty?NetworkImage(avatarUrl!):null,child:(avatarUrl??'').isEmpty?const Icon(Icons.person_rounded,size:34):null),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Flexible(child:Text(displayName,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800))),if(isVip)const Padding(padding:EdgeInsets.only(left:6),child:Icon(Icons.workspace_premium,color:Color(0xFFFFD76A),size:18))]),Text('$region • $language',style:TextStyle(color:Colors.white.withValues(alpha:.52)))])),_coinPill()])),
    const SizedBox(height:14),ListTile(leading:const Icon(Icons.workspace_premium_rounded,color:Color(0xFFFFD76A)),title:Text(isVip?'NEON VIP active':'Upgrade to NEON VIP'),subtitle:const Text('Priority matching, filters and perks'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const VipScreen()))),
    ListTile(leading:const Icon(Icons.edit_rounded),title:const Text('Edit profile'),trailing:const Icon(Icons.chevron_right),onTap:()async{await Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProfileScreen()));_loadProfile();}),
    if(isAdmin)ListTile(leading:const Icon(Icons.admin_panel_settings_rounded,color:NeonTheme.pink),title:const Text('Admin moderation'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminScreen()))),
    ListTile(leading:const Icon(Icons.logout_rounded),title:const Text('Sign out'),onTap:()=>AuthService().signOut()),
  ]));
}
