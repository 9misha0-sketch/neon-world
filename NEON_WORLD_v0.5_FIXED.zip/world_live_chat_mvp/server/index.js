import express from 'express';
import crypto from 'crypto';
import { AccessToken } from 'livekit-server-sdk';

const app = express();
app.use(express.json({ limit: '64kb' }));

const waiting = new Map();
const matches = new Map();

const LIVEKIT_URL = process.env.LIVEKIT_URL;
const LIVEKIT_API_KEY = process.env.LIVEKIT_API_KEY;
const LIVEKIT_API_SECRET = process.env.LIVEKIT_API_SECRET;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

function assertConfig() {
  const missing = Object.entries({ LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET, SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY }).filter(([,v])=>!v).map(([k])=>k);
  if (missing.length) throw new Error(`Missing server environment variables: ${missing.join(', ')}`);
}

async function authenticate(req,res,next){
  try{
    const auth=req.headers.authorization||'';
    if(!auth.startsWith('Bearer '))return res.status(401).json({error:'Missing bearer token'});
    const token=auth.slice(7);
    const response=await fetch(`${SUPABASE_URL}/auth/v1/user`,{headers:{Authorization:`Bearer ${token}`,apikey:SUPABASE_ANON_KEY}});
    if(!response.ok)return res.status(401).json({error:'Invalid session'});
    req.user=await response.json(); next();
  }catch(e){res.status(500).json({error:'Authentication check failed'});}
}

async function rest(path,options={}){
  const response=await fetch(`${SUPABASE_URL}/rest/v1/${path}`,{...options,headers:{apikey:SUPABASE_SERVICE_ROLE_KEY,Authorization:`Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,'Content-Type':'application/json',Prefer:'return=representation',...(options.headers||{})}});
  if(!response.ok)throw new Error(`Supabase REST ${response.status}: ${await response.text()}`);
  const text=await response.text(); return text?JSON.parse(text):null;
}

async function getProfile(userId){
  const rows=await rest(`profiles?id=eq.${encodeURIComponent(userId)}&select=id,display_name,avatar_url,gender,rating,is_vip,is_admin,coins,is_banned`);
  return rows?.[0]||null;
}

async function isBlocked(a,b){
  const rows=await rest(`blocks?or=(and(blocker_id.eq.${a},blocked_id.eq.${b}),and(blocker_id.eq.${b},blocked_id.eq.${a}))&select=blocker_id&limit=1`);
  return Array.isArray(rows)&&rows.length>0;
}

async function areFriends(a,b){
  const rows=await rest(`friend_requests?status=eq.accepted&or=(and(sender_id.eq.${a},receiver_id.eq.${b}),and(sender_id.eq.${b},receiver_id.eq.${a}))&select=id&limit=1`);
  return Array.isArray(rows)&&rows.length>0;
}

function compatible(a,b){
  const regionOk=a.region==='Worldwide'||b.region==='Worldwide'||a.region===b.region;
  const languageOk=a.language==='Any language'||b.language==='Any language'||a.language===b.language;
  const wants=(pref,gender)=>pref==='Everyone'||pref===gender;
  const genderOk=wants(a.genderPreference,b.gender)&&wants(b.genderPreference,a.gender);
  return regionOk&&languageOk&&genderOk;
}

async function requireAdmin(req,res,next){
  try{const p=await getProfile(req.user.id);if(!p?.is_admin)return res.status(403).json({error:'Admin only'});next();}
  catch(e){res.status(500).json({error:'Admin check failed'});}
}

async function makeToken(roomName,userId,displayName){
  const token=new AccessToken(LIVEKIT_API_KEY,LIVEKIT_API_SECRET,{identity:userId,name:displayName,ttl:'10m'});
  token.addGrant({roomJoin:true,room:roomName,canPublish:true,canSubscribe:true}); return token.toJwt();
}

async function matchedPayload(userId){
  const match=matches.get(userId); if(!match)return {status:'waiting'};
  const profile=await getProfile(userId);
  return {status:'matched',roomName:match.roomName,liveKitUrl:LIVEKIT_URL,token:await makeToken(match.roomName,userId,profile?.display_name||'User'),partner:{id:match.partnerId,displayName:match.partnerName,avatarUrl:match.partnerAvatar,rating:match.partnerRating,isVip:match.partnerVip}};
}

app.get('/health',(_,res)=>res.json({ok:true,waiting:waiting.size,matched:matches.size}));

app.post('/match/join',authenticate,async(req,res)=>{
  try{
    const userId=req.user.id;
    if(matches.get(userId))return res.json(await matchedPayload(userId));
    const profile=await getProfile(userId);
    if(!profile)return res.status(409).json({error:'Complete your profile first'});
    if(profile.is_banned)return res.status(403).json({error:'Account is banned'});
    const candidate={userId,displayName:profile.display_name||'User',region:String(req.body?.region||'Worldwide').slice(0,40),language:String(req.body?.language||'Any language').slice(0,40),genderPreference:String(req.body?.genderPreference||'Everyone').slice(0,30),gender:profile.gender||'Prefer not to say',avatarUrl:profile.avatar_url||null,rating:profile.rating||5,isVip:!!profile.is_vip,joinedAt:Date.now()};
    waiting.delete(userId);
    for(const [otherId,other] of waiting){
      if(!compatible(candidate,other))continue;
      if(await isBlocked(userId,otherId))continue;
      const otherProfile=await getProfile(otherId);
      if(!otherProfile||otherProfile.is_banned){waiting.delete(otherId);continue;}
      waiting.delete(otherId);
      const roomName=`match-${crypto.randomUUID()}`;
      matches.set(userId,{roomName,partnerId:otherId,partnerName:other.displayName,partnerAvatar:other.avatarUrl,partnerRating:other.rating,partnerVip:other.isVip});
      matches.set(otherId,{roomName,partnerId:userId,partnerName:candidate.displayName,partnerAvatar:candidate.avatarUrl,partnerRating:candidate.rating,partnerVip:candidate.isVip});
      return res.json(await matchedPayload(userId));
    }
    waiting.set(userId,candidate);res.json({status:'waiting'});
  }catch(e){console.error(e);res.status(500).json({error:'Matchmaking failed'});}
});

app.get('/match/status',authenticate,async(req,res)=>{try{res.json(await matchedPayload(req.user.id));}catch(e){console.error(e);res.status(500).json({error:'Could not read match status'});}});
app.post('/match/leave',authenticate,(req,res)=>{const userId=req.user.id;waiting.delete(userId);const current=matches.get(userId);matches.delete(userId);if(current)matches.delete(current.partnerId);res.json({ok:true});});

app.post('/safety/report',authenticate,async(req,res)=>{try{const reporterId=req.user.id,target=String(req.body?.targetUserId||''),reason=String(req.body?.reason||'').slice(0,300);if(!target||!reason||target===reporterId)return res.status(400).json({error:'Invalid report'});await rest('reports',{method:'POST',body:JSON.stringify({reporter_id:reporterId,reported_id:target,reason})});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not submit report'});}});
app.post('/safety/block',authenticate,async(req,res)=>{try{const me=req.user.id,target=String(req.body?.targetUserId||'');if(!target||target===me)return res.status(400).json({error:'Invalid block'});await rest('blocks?on_conflict=blocker_id,blocked_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify({blocker_id:me,blocked_id:target})});const current=matches.get(me);matches.delete(me);if(current)matches.delete(current.partnerId);res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not block user'});}});

app.get('/social/requests',authenticate,async(req,res)=>{try{const me=req.user.id;const rows=await rest(`friend_requests?receiver_id=eq.${me}&status=eq.pending&select=id,sender_id,created_at&order=created_at.desc`);const out=[];for(const r of rows){const p=await getProfile(r.sender_id);if(p)out.push({id:r.id,sender_id:r.sender_id,created_at:r.created_at,profiles:{display_name:p.display_name,avatar_url:p.avatar_url}});}res.json({requests:out});}catch(e){console.error(e);res.status(500).json({error:'Could not load requests'});}});
app.get('/social/friends',authenticate,async(req,res)=>{try{const me=req.user.id;const rows=await rest(`friend_requests?status=eq.accepted&or=(sender_id.eq.${me},receiver_id.eq.${me})&select=sender_id,receiver_id,created_at`);const out=[];for(const r of rows){const id=r.sender_id===me?r.receiver_id:r.sender_id;if(await isBlocked(me,id))continue;const p=await getProfile(id);if(p&&!p.is_banned)out.push({id:p.id,display_name:p.display_name,avatar_url:p.avatar_url,rating:p.rating,is_vip:p.is_vip});}res.json({friends:out});}catch(e){console.error(e);res.status(500).json({error:'Could not load friends'});}});
app.get('/social/messages/:userId',authenticate,async(req,res)=>{try{const me=req.user.id,target=String(req.params.userId||'');if(!(await areFriends(me,target)))return res.status(403).json({error:'Messages are friends-only'});if(await isBlocked(me,target))return res.status(403).json({error:'Messaging unavailable'});const rows=await rest(`messages?or=(and(sender_id.eq.${me},receiver_id.eq.${target}),and(sender_id.eq.${target},receiver_id.eq.${me}))&select=id,sender_id,receiver_id,body,created_at&order=created_at.asc&limit=500`);res.json({messages:rows});}catch(e){console.error(e);res.status(500).json({error:'Could not load messages'});}});

app.post('/social/friend-request',authenticate,async(req,res)=>{try{const me=req.user.id,target=String(req.body?.targetUserId||'');if(!target||target===me)return res.status(400).json({error:'Invalid user'});if(matches.get(me)?.partnerId!==target && !(await areFriends(me,target)))return res.status(403).json({error:'Friend requests can be sent to your current match only'});if(await isBlocked(me,target))return res.status(409).json({error:'Friend request unavailable'});const reverse=await rest(`friend_requests?sender_id=eq.${target}&receiver_id=eq.${me}&status=eq.pending&select=id&limit=1`);if(reverse?.length){await rest(`friend_requests?id=eq.${reverse[0].id}`,{method:'PATCH',body:JSON.stringify({status:'accepted'})});}else{await rest('friend_requests?on_conflict=sender_id,receiver_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify({sender_id:me,receiver_id:target,status:'pending'})});}res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not send friend request'});}});
app.post('/social/friend-response',authenticate,async(req,res)=>{try{const id=Number(req.body?.requestId),accept=!!req.body?.accept;const rows=await rest(`friend_requests?id=eq.${id}&receiver_id=eq.${req.user.id}&status=eq.pending&select=id`);if(!rows?.length)return res.status(404).json({error:'Request not found'});await rest(`friend_requests?id=eq.${id}`,{method:'PATCH',body:JSON.stringify({status:accept?'accepted':'declined'})});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not update friend request'});}});
app.post('/social/message',authenticate,async(req,res)=>{try{const me=req.user.id,target=String(req.body?.targetUserId||''),body=String(req.body?.body||'').trim().slice(0,1000);if(!target||!body||target===me)return res.status(400).json({error:'Invalid message'});if(!(await areFriends(me,target)))return res.status(403).json({error:'Messages are friends-only'});if(await isBlocked(me,target))return res.status(403).json({error:'Messaging unavailable'});await rest('messages',{method:'POST',body:JSON.stringify({sender_id:me,receiver_id:target,body})});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not send message'});}});

const giftCosts={rose:10,star:25,heart:50,crown:100};
app.post('/wallet/gift',authenticate,async(req,res)=>{try{const me=req.user.id,target=String(req.body?.targetUserId||''),key=String(req.body?.giftKey||''),cost=giftCosts[key];if(!target||target===me||!cost)return res.status(400).json({error:'Invalid gift'});const current=matches.get(me);if(current?.partnerId!==target && !(await areFriends(me,target)))return res.status(403).json({error:'Gifts are available to your current match or friends'});if(await isBlocked(me,target))return res.status(403).json({error:'Gift unavailable'});await rest('rpc/send_gift_tx',{method:'POST',body:JSON.stringify({p_sender:me,p_receiver:target,p_key:key,p_cost:cost})});const p=await getProfile(me);res.json({ok:true,coins:p?.coins??0});}catch(e){console.error(e);res.status(409).json({error:String(e.message||e).includes('not enough coins')?'Not enough coins':'Could not send gift'});}});

app.post('/social/rate',authenticate,async(req,res)=>{try{const me=req.user.id,target=String(req.body?.targetUserId||''),stars=Number(req.body?.stars);if(!target||target===me||!Number.isInteger(stars)||stars<1||stars>5)return res.status(400).json({error:'Invalid rating'});if(matches.get(me)?.partnerId!==target)return res.status(403).json({error:'You can rate your current match only'});await rest('ratings?on_conflict=rater_id,rated_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify({rater_id:me,rated_id:target,stars})});const rows=await rest(`ratings?rated_id=eq.${target}&select=stars`);const count=rows.length;const rating=count?rows.reduce((a,x)=>a+Number(x.stars),0)/count:5;await rest(`profiles?id=eq.${target}`,{method:'PATCH',body:JSON.stringify({rating:Number(rating.toFixed(2)),rating_count:count})});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not save rating'});}});

app.get('/admin/reports',authenticate,requireAdmin,async(req,res)=>{try{const reports=await rest('reports?status=eq.open&select=id,reporter_id,reported_id,reason,status,created_at&order=created_at.desc&limit=100');res.json({reports});}catch(e){console.error(e);res.status(500).json({error:'Could not load reports'});}});
app.post('/admin/report-action',authenticate,requireAdmin,async(req,res)=>{try{const id=Number(req.body?.reportId),ban=!!req.body?.ban;const rows=await rest(`reports?id=eq.${id}&select=id,reported_id`);if(!rows?.length)return res.status(404).json({error:'Report not found'});if(ban)await rest(`profiles?id=eq.${rows[0].reported_id}`,{method:'PATCH',body:JSON.stringify({is_banned:true})});await rest(`reports?id=eq.${id}`,{method:'PATCH',body:JSON.stringify({status:ban?'banned':'resolved'})});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not update report'});}});

try{assertConfig();}catch(e){console.error(e.message);process.exit(1);}
app.listen(process.env.PORT||3000,()=>console.log(`World Live Chat API listening on ${process.env.PORT||3000}`));
