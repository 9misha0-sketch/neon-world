# NEON WORLD v0.5

Global 18+ random 1:1 video chat MVP in Flutter with a neon mobile-first interface.

The app is now connected to the live **Neon chat** Supabase backend and uses Supabase Edge Functions for matchmaking and secure LiveKit token creation. See `CONNECTED_BACKEND.md` for deployment and device instructions.

## Included

- Email signup/login
- 18+ profile onboarding
- Avatar upload
- Country/language/gender preference filters
- Random matching
- LiveKit 1:1 camera + microphone
- Next / leave
- Block + report
- Friend requests
- Friends / inbox / private messages
- Coins / gifts
- Ratings
- VIP state
- Admin moderation backend

## Security

Only the Supabase publishable key is present in the mobile source. LiveKit API credentials remain server-side in Supabase Secrets.
