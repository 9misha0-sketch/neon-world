import 'package:supabase_flutter/supabase_flutter.dart';

class AdminService {
  final _db = Supabase.instance.client;

  Future<Map<String, dynamic>> _invoke(Map<String, dynamic> body) async {
    final r = await _db.functions.invoke('admin', body: body);
    final d = Map<String, dynamic>.from(r.data as Map);
    if (d['error'] != null) throw Exception(d['error']);
    return d;
  }

  Future<List<Map<String, dynamic>>> reports() async {
    final d = await _invoke({'action': 'list_reports'});
    return List<Map<String, dynamic>>.from(d['reports'] ?? const []);
  }

  Future<void> resolve(String reportId, {required bool ban}) async {
    await _invoke({'action': 'resolve_report', 'reportId': reportId, 'ban': ban});
  }
}
